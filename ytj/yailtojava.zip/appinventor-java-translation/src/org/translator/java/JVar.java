package org.translator.java;

import java.util.ArrayList;

public class JVar {
	private String type;
	private String name;
	private String val;
	private ArrayList<String> members;
	public JVar(String name){
		this.name=name;
		val=null;
		type=null;
		members=null;
	}
	public ArrayList<String> getMembers(){
		return members;
	}
	public void setMembers(ArrayList<String> members){
		this.members=members;
	}
	public void setType(String type){
		this.type=type;
	}
	public void setVal(String val){
		this.val=val;
	}
	public String getName(){
		return name;
	}
	public String getType(){
		return type;
	}
	public String getVal(){
		return val;
	}
}
