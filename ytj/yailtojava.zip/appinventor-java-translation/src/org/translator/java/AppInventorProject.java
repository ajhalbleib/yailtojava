/*
   appinventor-java-translation

   Originally authored by Joshua Swank at the University of Alabama
   Work supported in part by NSF award #0702764 and a Google 2011 CS4HS award

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package org.translator.java;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

/**
 *
 * @author jswank
 * 
 * @edited by Aaron & Ramya
 */
public class AppInventorProject {
    private final HashMap<String, AppInventorScreen> screens = new HashMap<String, AppInventorScreen>();

    public AppInventorProject( File inputFile ) throws IOException
    {
        load( inputFile );
    }

    public static void main(String [] args) {
    	File inputFile = new File(args[0]);
    	try {
			new AppInventorProject(inputFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    private void load( File inputFile ) throws IOException
    {
        InputStream inputStream = null;

           if (inputFile.getName().toLowerCase().endsWith( ".yail" ) || inputFile.getName().toLowerCase().endsWith( ".java" )){
            	inputStream=new FileInputStream(inputFile);
            	load(inputStream,inputFile.getName());
            	inputStream.close();
            }
    }

    private void load( InputStream inputStream, String myname ) throws IOException
    {
        if (myname.endsWith(".yail") || myname.endsWith(".java")){
        	loadSourceFile( myname, inputStream );
        	generateSource();
        	return;
        }
    }
   
    private void loadSourceFile( String path, InputStream inputStream ) throws IOException
    {
    	//screens hash map will always have only one key/value pair, because he uses the same
    	//key for each file, which will always result in the previous value being overwritten.
    	//practically, this means the last file passed to this method will be the only one
    	//with a corresponding AppInventorScreens object in the HashMap
        //projectName = getFolder( path );
        //String screenName = getScreenName( path );
        AppInventorScreen screen = new AppInventorScreen( path.substring(0,path.length()-5 ), inputStream );
        if (path.endsWith(".yail") || path.endsWith(".java")){
            screen.loadYailFile();
            screens.put( path.substring(0,path.length()-5 ), screen );
        }
    }

    private void generateSource()
    {
       for( AppInventorScreen screen : screens.values() ){
        	System.out.println(screen.generateJavaFile().toString());
        	return;
        }
    }


}
